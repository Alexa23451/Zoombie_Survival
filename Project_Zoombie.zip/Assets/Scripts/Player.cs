﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	public int health = 100;
	public GameObject bulletPrefab;
	
	void Update () {

		if (Input.GetMouseButtonDown(0)) {

				SoundManager.Instance.PlayAudio(SoundManager.Instance.shotSound);

                GameObject bulletObject = Instantiate(bulletPrefab);
                bulletObject.transform.position = this.transform.position;

                Bullet bullet = bulletObject.GetComponent<Bullet>();
                bullet.direction = transform.forward;
            
		}
	}
}
